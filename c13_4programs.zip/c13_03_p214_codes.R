# c13_p214_codes.R


x<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)
n<-length(p)
p<- -diff(x[,7])
n1<-21
cov1<-NA
s<-NA

for(i in 1:(n-n1)){

     m1<-i
     m2<-i+n1
     cov0<-cov(p[m1:m2],p[(m1+1):(m2+1)])
     cov1[i]<-min(cov0,0)
     s[i]<-2*sqrt(-cov1[i])

}

s2<-s[is.na(s)==F]

mean(s2)
