# c13_p212_codes.R



 x<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)
 x[1:2,]

 p<-diff(x[1:500,7]) # using the latest 500 trading days

 n<-length(p)

 cov(p[1:(n-1)],p[2:n])


