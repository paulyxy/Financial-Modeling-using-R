# c13_p213_codes.R


 ticker<-"DELL"
 n_days<-252
 html<-paste("http://chart.yahoo.com/table.csv?s=",ticker,sep="")
 x<-read.csv(html,header=T)
 p<- -diff(x[,7])
 cov1<-cov(p[1:n_days],p[2:(n_days+1)])
 cov1

 2*sqrt(-cov1)

