#  c05_p102_loop_tickers.R

stocks<-c("IBM", "DELL")

for(stock in stocks) { 

    print(stock)

    k<-'http://ichart.finance.yahoo.com/table.csv?s=$V&amp;a=00&amp;b=2&amp;c=2010&amp;d=05&amp;e=2&amp;f=2010&amp;g=d&amp;ignore=.csv'

    k1<-sub("$V",stock,k,fixed=T)

    x<-read.csv(k1)

    print(head(x))
}




