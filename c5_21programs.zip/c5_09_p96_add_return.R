#  c05_p96_add_return.R


   x<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)
   n<-nrow(x)
   ret2<-NA
   for (in in 1:(n-1))
        ret2[i]<-(x[i,7]-x[i+1,7])/x[i+1,7]



   x<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)
   n<-nrow(x)
   ret<-(x[1:(n-1),7]-x[2:n,7])/x[2:n,7])



   x<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)
   d<-data.frame(format(as.Date(x[,1]),"%Y%m%d"),as.real(x[,7]))
   d<-d[order(d[,1]),]      # Sort by date (ascending)
   n<-nrow(d)
   ibm<-data.frame(d[2:n,1],d[2:n,2],(d[2:n,2]-d[1:n-1,2])/d[1:n-1,2])
   colnames(ibm)<-c('date','adj_price','ret')




