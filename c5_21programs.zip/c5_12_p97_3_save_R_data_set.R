#  c05_p97_3_save_R_data_set.R



  x<-read.csv("http://chart.yahoo.com/table.csv?s=DELL",header=T)

  save(x,file='ibm.RData')







