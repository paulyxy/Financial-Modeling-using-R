#  c05_p96_add_ticker.R


 x<-read.csv("http://chart.yahoo.com/table.csv?s=DELL",header=T)

 d<-cbind("DELL",x)

 t<-colnames(d)

 t[1]<-"ticker"

 colnames(d)<-t

 d[1:2,]
