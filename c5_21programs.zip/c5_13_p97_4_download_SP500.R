#  c05_p97_4_download_SP500.R


  x<-read.csv("http://chart.yahoo.com/table.csv?s=^GSPC",header=T)





