#  c05_p99_EDm1.R

  # EDm1 Euro
  # http://www.federalreserve.gov/datadownload/


  x<-read.csv("h15_ED_m1.txt",skip=6)





