#  c05_p95_2_sorted_data.R


 x<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)