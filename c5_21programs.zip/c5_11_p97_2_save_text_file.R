#  c05_p97_2_save_text_file.R


 x<-read.csv("http://chart.yahoo.com/table.csv?s=Yahoo",header=T)

 write.table(x,file='yahoo.txt',quote=F,row.names=F)


     # it is better to use the following command 

 write.table(x,file='c.csv',sep=',',quote=F,row.names=F)


    # Alternatively, we use the write.csv() function. 

 write.csv(x,file='c.csv',quote=F,row.names=F)






