#  c05_p91_yahoo_data_IBM.R

  x<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)