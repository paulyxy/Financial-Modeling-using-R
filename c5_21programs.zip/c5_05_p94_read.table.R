#  c05_p94_read.table.R


  x<-read.table('ibm.csv',sep=',',header=T)  # relative path

  x[1:2,]



  infile <-'c:/test_R/ibm.csv'     # absolute path

   x<-read.table(infile,sep=',',header=T)





