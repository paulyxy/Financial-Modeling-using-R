#  c05_p100_loop_tickers.R

  stocks<-c("IBM", "DELL")
 
   for(stock in stocks) print(stock)




tickers<-c("IBM", "DELL")

for(stock in tickers){ 

    print(stock)

    k<-'http://chart.yahoo.com/table.csv?s=$V' # variable $V

    k1<-sub("$V",stock,k,fixed=T)   # sub() for substitution

    x<-read.csv(k1)

    print(x[1:2,])
}



