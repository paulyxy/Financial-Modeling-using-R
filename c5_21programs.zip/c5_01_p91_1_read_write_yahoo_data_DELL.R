#  c05_p91_read_write_DELL.R

 x<-read.csv("http://chart.yahoo.com/table.csv?s=DELL",header=T)

 write.table(x,file='dell.txt',quote=F,row.names=F)
