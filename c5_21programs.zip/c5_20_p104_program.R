#  c05_p104_program.R


beg<-as.Date("2000-02-01") 

end<-as.Date("2000-05-31")

x<-seq(beg,end,by=1)     # generate 365 calendar days

n<-length(x)

y<-as.Date("2000-02-01")

j=1

for(i in 1:(n-1)){

    today_month    <-format(x[i], "%m")

    tomorrow_month <-format(x[i+1],"%m")

    if(today_month != tomorrow_month){

        y[j]<-x[i]

        j<-j+1
    }

}

if(format(y[j-1],"%m") !=format(x[n],"%m"))
   y[j]<-x[n]






