#  c05_p102_2_fine_tuning.R


   ibm[,3]=round(ibm[,3],digits=6)     # six decimal places


   write.table(ibm,file="ibm_ret",quote=F,row.names=F)


   save(ibm,file="ibm.RData")





k<-'http://ichart.finance.yahoo.com/table.csv?s=$V&amp;a=00&amp;b=2&amp;c=1962&amp;d=05&amp;e=2&amp;f=2010&amp;g=d&amp;ignore=.csv'

k1<-sub("$V",stock,k,fixed=T)

x<-read.csv(k1)



