#  c05_p98_monthly_data.R


 k1<-'http://ichart.finance.yahoo.com/table.csv?s=IBM&amp;'

 k2<-'a=01&amp;b=01&amp;c=2010&amp;d=31&amp;e=12&amp;'

 k3<-'f=2010&amp;g=m&amp;ignore=.csv'

 k<-paste(k1,k2,k3,sep='')

 x<-read.csv(file=k,header=T)








