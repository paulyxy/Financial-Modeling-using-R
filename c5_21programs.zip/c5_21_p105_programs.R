#  c05_p105_programs.R



 x<-seq(as.Date("2000-02-01"),as.Date("2000-05-31"),"days")
 
 n<-length(x)

 y<-subset(x,format(x[1:(n-1)],"%m")!=format(x[2:n],"%m"))

 n2<-length(y)

 if(format(y[n2],"%m") !=format(x[n],"%m"))

 y[n2+1]<-x[n]





  month_<-function(x)  as.integer(format(x,"%m"))

  x<-seq(as.Date("2000-02-01"),as.Date("2000-05-31"),by=1)

  n<-length(x) 

  y<-subset(x,month(x[1:(n-1)])!=month_(x[2:n]))

  n2<-length(y)

  if(format(y[n2],"%m") !=format(x[n],"%m"))

  y[n2+1]<-x[n]




