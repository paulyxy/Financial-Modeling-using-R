#  c05_p94_date_variable.R




  x<-as.Date("1990-01-31","%Y-%m-%d")

  x+1


   x<-as.Date("1990/01/31","%Y/%m/%d")

   y<-as.Date("01/31/1990","%m/%d/%Y")










