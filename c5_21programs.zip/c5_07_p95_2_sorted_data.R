#  c05_p95_2_sorted_data.R



 x<-read.table('ibm.csv',sep=',',header=T)

 d<-data.frame(as.Date(x[,1],format="%Y%m%d"),as.real(x[,7]))

 d<-d[order(d[,1]),]         # Sort by date (ascending)

 ibm<-data.frame(d[,1],d[,2])

 colnames(ibm)<-c('date','adj_price')

 head(x)

