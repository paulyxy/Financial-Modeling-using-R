#  c05_p95_date_variable.R


 as.Date("1990-01-31")+1


 as.Date("1990/01/31")+2


 x<-as.Date("1990\01\31")








