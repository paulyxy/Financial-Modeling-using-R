#  c05_p99_EDm1.R

  # EDm1 Euro
  # http://www.federalreserve.gov/datadownload/


  x<-read.csv("h15_ED_m1.txt",skip=6)

  y<-subset(x,x[,2]==' ND')

  y[1:3,]



  t1<-c(1,2,3)            # 1st column
  t2<-c(2,4,5)            # 2nd column
  t3<-cbind(t1,t2)        # combine them 

  t3
 
  t3<-subset(t3,t3[,2]>4) # select a subset with a condition 

  t3
  
   dim(x)

   x2<-subset(x,x[,2]!='ND')

   dim(x2)


