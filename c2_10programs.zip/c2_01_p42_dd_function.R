"
  Name     : c2_01_p42_dd_function.R
  Book     : Financial Modeling using R (2018)
  Author   : Yuxing Yan
  ISBN     : 9-78-1-94696454
  Publisher: Legaia Books 
  Amazon   : http://canisius.edu/~yany/amazonR2018.shtml
  Date     : 3/7/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"

dd<-function(x)x*2