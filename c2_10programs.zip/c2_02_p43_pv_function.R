#  c02_p43_pv_function.R

pv_f<-function(fv,r,n) fv/(1+r)^n