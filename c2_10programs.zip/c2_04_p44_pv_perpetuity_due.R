#  c02_p44_2_pv_perpetuity_due.R

pv_perpetuity_due<-function(c,r){

" 
Objective: estimate the present value of a perpetuity
        c: cash flow (1st at the end of 1st period
        r: effective period discount rate
  e.g.,
         > pv_perpetuity(10,0.08)
           [1] 125   

"
return(c/r*1(1+r))

}
