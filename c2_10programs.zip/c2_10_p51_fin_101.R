#  c02_p51_fin_101.R

# fin_101.R

"
  Objective : a set of 50 programs related to Finance 101
  Author    : John Doe
  Date      : 10/2/2013
  Modified  : 7/3/2014
  A list of all functions

   1)	pv_f()
   2)	fv_f()
   3)	IRR()
   4)	Bond_price()
   5)	pv_annuity()
   6)	pv_perpeturity()
"

# program one 

# program two 

# program three 
