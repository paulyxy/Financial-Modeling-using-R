#  c02_p47_pv_f_with_comments.R

pv_f<-function(fv,r,n) {
  "
   Objective: estimate present value
      fv : future value
      r  : discount rate
      n  : number of periods
      e.g.,
       >  pv_f(100,0.1,1)
         [1] 90.90909
  "
  return(fv*(1+r)^(-n))
}
