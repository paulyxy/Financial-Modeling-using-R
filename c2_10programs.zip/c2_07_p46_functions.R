#  c02_p46_3_functions.R

pv_f<-function(fv,r,n)fv/(1+r)^n
fv_f<-function(pv,r,n) pv*(1+r)^n
pv_perpetuity<-function(c,r)c/r
