# c09_p151_2_correlatedRandomNumbers.R


 x1<-rnorm(1000)

 x2<-rnorm(1000)
 
 cor(x1,x2)


 rho<-0.5 # assume a value

 y1<-x1

 y2<-x1*rho + sqrt(1-rho^2)*x2

 cor(y1,y2)