# c09_p146.R

 x<-rnorm(100, mean = 5, sd = 3)

 mean(x)

 sd(x)
