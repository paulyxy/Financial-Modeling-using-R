# c09_p144_3.R

 set.seed(729)

 x<-unique(as.integer(runif(20,1,500)))

 x2<-x[1:10]

 x2

