# c09_p144_2.R


 set.seed(123)

 x<- rnorm(100)

