# c09_p152.R


set.seed(124)

m<-5                      # number of stocks a choice variable

load("retM50.RData")

n_stock<-length(unique(retM50[,1]))

x<-unique(as.integer(runif(2200,0,n_stock))%%n_stock+1)

id<-matrix(x[1:m],m,1)

colnames(id)<-"ID"

y2<-unique(retM50[,1])

id2<-1:n_stock

stocks<-data.frame(y2,id2)

colnames(stocks)<-c("ticker","ID")

final<-merge(stocks,id,by="ID")

