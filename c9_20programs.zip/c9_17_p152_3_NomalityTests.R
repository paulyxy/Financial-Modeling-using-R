# c09_p152_3_normalityTests.R


 x<-rnorm(1000)

 mean(x)

 sd(x)

 shapiro.test(x)



# ----------------------

 x<-runif(1000)

 shapiro.test(x)







