# c09_p145_2.R

 x<-runif(1000)

 min(x)

 max(x)

 mean(x)