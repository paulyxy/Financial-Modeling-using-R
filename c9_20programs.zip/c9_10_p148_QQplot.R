# c09_p148_QQplot.R

# normal Q-Q plot

 x<-rnorm(1000)

 qqnorm(x)


# -----------------

 x<-runif(1000)

 qqnorm(x)


# -----------------

 mu<-0.25

 std<-0.3

 n<-100

 rnorm(n,mu,std) 


 log_normal_random<-function(n) return(rlnorm(n))


