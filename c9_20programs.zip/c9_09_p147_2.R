# c09_p147_2.R


 rnorm(10)

 rnorm(10)

 set.seed(10)

 rnorm(10)


