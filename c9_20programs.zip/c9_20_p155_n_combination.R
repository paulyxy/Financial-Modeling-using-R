# c09_p155_n_combination.R


n_combinations<-function(n,r)gamma(n+1)/gamma(r+1)/gamma(n-r+1)



