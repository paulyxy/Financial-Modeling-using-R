# c09_p147_1.R

 x<-rnorm(100, mean = 0, sd = 1)

 x2<-rnorm(100)