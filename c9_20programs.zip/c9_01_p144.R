# c09_p144.R


 x<- rnorm(100)
