# c09_p154_factorialFunction.R


 factorial(4)


# -----------------------

fac<-function(n){
  
  if(n==1)

      return(1)

  else

     return(n*fac(n-1))

}

# ---------------------------

factorial_f<-function(n) gamma(n+1)

 factorial_f(8)






