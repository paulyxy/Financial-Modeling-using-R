# c09_p144_bsCallSimuation.R

bsCallSimulation<-function(s,x,T,r,sigma,n=100){

     ST<-s*exp((r-sigma*sigma/2.0)*T + sigma*rnorm(n)*sqrt(T))

     mean(((ST-x) + abs(ST-x))/2)*exp(-r*T)


}

 bs_call(40,42,0.5,0.1,0.2)

 set.seed(212)

 bsCallSimulation(40,42,0.5,0.1,0.2,5000)


