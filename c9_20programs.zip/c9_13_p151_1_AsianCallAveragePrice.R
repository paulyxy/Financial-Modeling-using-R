# c09_p151_asianCallAveragePrice.R

asian_call_ave_price<-function(S,r,T,n_steps,sigma,x,n_trial){

    payoff<-payoff<-rep(0,time=n_trial) # initialization

    for(i in 1:n_trial){

         Saverage<- mean(ST_path_f(S,r,T,n_steps,sigma))
   
         payoff[i]<-max(Saverage-x,0)
    }

    return(mean(payoff)*exp(-r*T))
}


asian_call_ave_price(50,0.1,1,1000,0.2,20,100)