# c09_p153_timeUsed.R


 set.seed(123)

 n<-100

 mean(rnorm(n))


 system.time(mean(rnorm(100000)))


# -----------------------------


 system.time(mean(rnorm(10000000)))











