# c09_p150_sT_f.R

# ---------------------------

ST_f<-function(S,r,T,sigma){

   S*exp((r-0.5*sigma*sigma)*T+sigma*rnorm(1)*sqrt(T))

}




# ---------------------------

call_f<-function(s,x,T,r,sigma){

   d1 = (log(s/x)+(r+sigma*sigma/2.)*T)/(sigma*sqrt(T))

   d2 = d1-sigma*sqrt(T)

   s*pnorm(d1)-x*exp(-r*T)*pnorm(d2)

}

bs_f('C',42,40,0.5,0.1,0.2) # usage: bs_f(flag,S,X,T,r,sigma)


# ---------------------------

bs_call_simulation<-function(s,x,r,T,sigma,n=100){

     ST<-s*exp((r-sigma*sigma/2.0)*T + sigma*rnorm(n)*sqrt(T))

     payoff<-((ST-x) + abs(ST-x))/2

     mean(payoff)*exp(-r*T)
}


 bs_simulation(42,40,0.1,0.5,0.2,5000)
