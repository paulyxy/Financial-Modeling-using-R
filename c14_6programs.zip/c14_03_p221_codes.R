# c14_p221_codes.R



 x<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)

 head(x,2)

 x<- readHTMLTable("http://finance.yahoo.com/q/ks?s=IBM+Key+Statistics")[9]

 x[29]


# -------------------


 x<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)
 mean(x[1:252,6])

 x2<-read.csv("http://chart.yahoo.com/table.csv?s=DELL",header=T)
 mean(x2[1:252,6])


