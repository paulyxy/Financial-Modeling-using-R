# c14_p222_codes.R

 ticker<-"DELL"
 year0<-2010
 web<-paste("http://chart.yahoo.com/table.csv?s=",ticker,sep="")
 x<-read.csv(web)
 x[1,]

 x2[,3]<-format(x2[,1],"%Y")
 colnames(x2)<-c("date","vol","year")
 x2[1,]
 x3<-subset(x2,x2$year==as.character(year0))
 dim(x3)

 sum(as.numeric(x3$vol))/1e9



 x<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)
 mean(x[1:252,6]*x[1:252,4])/10e6

 x2<-read.csv("http://chart.yahoo.com/table.csv?s=DELL",header=T)
 mean(x2[1:252,6]*x2[1:252,4])/10e6



