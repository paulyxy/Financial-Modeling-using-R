# c14_p220_codes.R

 library(XML)

 readHTMLTable("http://finance.yahoo.com/q/ks?s=IBM+Key+Statistics")[9]