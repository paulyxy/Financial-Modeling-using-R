# c14_p223_illiq.R


 x<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)

 n<-nrow(x)

 ret<-data.frame(as.Date(x[1:(n-1),1]),x[1:(n-1),5:6],(x[1:(n-1),7]-x[2:n,7])/x[2:n,7])

 colnames(ret)<-c("date","price","vol","ret")

 date1<-as.Date("2011-03-21")

 date2<-as.Date("2011-04-21")

 y<-ret[ret[,1]=date1 &ret[,1]<=date2,]

 illiq<-sum(y[,4]/(y[,2]*y[,3]))/nrow(y)

 illiq
