# c14_p224_codes.R


s<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)

n<-nrow(s)

ret<-data.frame(as.Date(s[1:(n-1),1]),s[1:(n-1),5:6],(s[1:(n-1),7]-s[2:n,7])/s[2:n,7])

colnames(ret)<-c("date","price","vol","ret")

i<-read.csv("http://chart.yahoo.com/table.csv?s=^GSPC",header=T)

n<-nrow(i)

mkt<-data.frame(as.Date(i[1:(n-1),1]),(i[1:(n-1),7]-x[2:n,7])/i[2:n,7])

colnames(mkt)<-c("date","mkt ")

final<-merge(ret,mkt)

head(final)



n1<-21

n2<-n1+1

y<-final$ret[1:n1]-final$mkt[1:n1]

x1<-final$ret[2:n2]-final$mkt[2:n2]

x2<-sign(x1)*final$price[2:n2]*final$vol[2:n2]

x<-cbind(x1,x2)

lm(y~x)


