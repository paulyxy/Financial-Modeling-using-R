# c15_p234_package_FinAsym.R



library(FinAsym)
x<-matrix(c(4.56, 4.7, 4.57, 4.64, 4.53,
4.65, 4.59, 4.66, 4.55, 4.65, 4.59, 4.66, 4.59,
4.66, 4.55, 4.65, 4.55, 4.65, 4.55, 4.65, 4.59,
4.66, 4.55, 4.65, 4.59, 4.66, 4.59, 4.66),nrow=14, byrow=TRUE)

 classify_quotes(x,1,2, "2/2/2012")

$no_trades

$sell_trades

$buy_trades

n_buy<-0

n_sell<-0

not_sure<-0

n<-nrow(x)

for(i in 2:n){

    if(mean(x[i,])mean(x[i-1,])){
        n_buy<-n_buy+1
     }else if (mean(x[i,])<mean(x[i-1,])){
        n_sell<-n_sell+1
     }else{
        not_sure<-not_sure+1
     }
}

cat("not_sure",not_sure,"\n")

cat("n_sell",n_sell,"\n")

cat("n_buy",n_buy, "\n")
