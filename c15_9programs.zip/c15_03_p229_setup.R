# c15_p229_setup.R


setup<-function(path,day){

  idx.T<<-file(paste(path,'T',day,'.idx',sep=""),'rb')
  idx.Q<<-file(paste(path,'Q',day,'.idx',sep=""),'rb')
  bin.T<<-file(paste(path,'T',day,'.bin',sep=""),'rb')
  bin.Q<<-file(paste(path,'Q',day,'.bin',sep=""),'rb')
  return('Four global variables: idx.T, idx.Q, bin.T and bin.Q')

}


path<-"c:/temp/" # modify this part accordingly

day<-"200411a "  # modify this part accordingly

setup(path,day)  # run just once



 readBin(idx.T,integer(),size=4,n=1,endian='little')

 readBin(idx.T,integer(),size=4,n=1,endian='little')



