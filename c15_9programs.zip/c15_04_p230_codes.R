# c15_p230_codes.R

 seek(idx.T,(100-1)*22)

 x<-readBin(idx.T,character(),size=4,n=1,endian='little')

 substr(x,1,10)


 seek(ind.T,(100-1)*22+10)


 readBin(ind.T,integer(),size=4,n=1,endian='little')

 readBin(ind.T,integer(),size=4,n=1,endian='little')

 readBin(ind.T,integer(),size=4,n=1,endian='little')


 seek(idx.T,where=-22,origin='end')

 x<-readBin(idx.T,character(),size=4,n=1,endian='little')

 substr(x,1,10)




 seek(idx.T,where=0,origin='end')

 p2<-seek(idx.T)

 p2/22


 readBin(bin.T, "integer",size=4,n=1,endian='little')


 h<-as.integer(34218/3600)
 h

 m<-as.integer((34218-h*3600)/60)
 m

 s<-34218-h*3600-m*60
 s
