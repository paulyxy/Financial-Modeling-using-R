# c15_p237_DOS_command.R


#  dir e:\TAQ_binary_data /b /s >t.txt