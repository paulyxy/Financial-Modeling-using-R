# c15_p233_codes.R



x<-get_trade("ibm",500)

y<-get_quote("ibm",500)

z<-merge(x,y,all=T)


# -------------------------


x<-get_trade("ibm",500)

x[1,]<-x[1,]+5

y<-get_quote("ibm",500)

z<-merge(x,y,all=T)



