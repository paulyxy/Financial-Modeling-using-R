# c15_p236_237_PIN.R



library(FinAsym)

x<-c(9,6,13)

B_S<- matrix(x,3,15) # structure of each column: N, B, S

par0 <- c(0.4, 0.5, 0.5, 0.5)

out <- optim(par0, pin_likelihood,gr=NULL,B_S)

alpha <- out$par[3]

mu <- out$par[2]

delta <- out$par[4]

epsi <- out$par[1]

pin <- alpha*mu/(alpha*mu+ 2*epsi)

print(pin)



 par0 <- c(0.4, 0.5, 0.5, 0.5)
 out <- optim(par0, pin_likelihood,gr=NULL,B_S)
 alpha <- out$par[3]
 mu <- out$par[2]
 delta <- out$par[4]
 epsi <- out$par[1]
 pin <- alpha*mu/(alpha*mu+ 2*epsi)

 pin


