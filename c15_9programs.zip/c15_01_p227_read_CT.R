# c15_p227_read_CT.R

 in.file<-file("c:/temp/T200411a.idx","rb")

 x<-readBin(in.file,character(),size=4,n=1,endian="little")

 substr(x,1,10)



