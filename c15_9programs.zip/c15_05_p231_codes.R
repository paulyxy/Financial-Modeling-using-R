# c15_p231_codes.R



for(i in 1:10){

    seek(in.file, (i-1)*29)

    print(readBin(in.file, "integer",size=4,n=1,endian='little'))

}

