# c15_p228_codes.R

 path_index_CT<-"c:/temp/T200411a.idx"

 index_CT<-file(path_index_CT, "rb")