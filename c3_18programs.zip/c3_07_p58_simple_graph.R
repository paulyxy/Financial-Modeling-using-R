#  c03_p58_1_simple_graph.R


 x<-seq(-5,5,by=0.2)

 y<-5+x^2

 plot(x,y)

