#  c03_p64_stradele.R

payoff_call<-function(sT,x)(sT-x+abs(sT-x))/2

payoff_put<-function(sT,x)(x-sT+abs(x-sT))/2

sT<-seq(0,50,by=5)

y<-payoff_call(sT,30)+payoff_put(sT,30)

plot(sT,y,�l�)


# the last parameter of plot() is a lower case of L
