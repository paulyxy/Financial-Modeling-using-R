#  c03_p60_2_profit_loss_put.R

sT<-seq(10,50,by=5)# stock prices

x<-30           # exercise price

n<-length(s)

payoff<-rep(0,n)

for (i in 1:n) {
   payoff[i]=max(x-sT[i],0)
}

plot(sT,payoff,type="l")
