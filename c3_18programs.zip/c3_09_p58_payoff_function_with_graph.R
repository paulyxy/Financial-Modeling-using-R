#  c03_p58_payoff_function_with_graph.R


sT<-seq(10,50,by=5)          # stock prices

x<-30                        # exercise price

payoff<-payoff_call(sT,x)

plot(sT,payoff,type="l")     # "l" is the lower case letter of L
