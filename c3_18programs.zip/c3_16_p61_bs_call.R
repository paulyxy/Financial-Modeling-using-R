#  c03_p61_bs_call.R


# Black-Scholes-Merton option model 

bs_call<-function(S,X,T,r,sigma){

"
Objective  : calculate call price
     S     : stock price today
     X     : exercise price
     r     : risk-free rate
     sigma : volatility of the stock

     e.g., > bs_call(40,42,0.5,0.1,0.2) 
             [1] 2.277780

"
 d1 = (log(S/X)+(r+sigma*sigma/2.)*T)/(sigma*sqrt(T))

 d2 = d1-sigma*sqrt(T)

 return(S*pnorm(d1)-X*exp(-r*T)*pnorm(d2))

}
