#  c03_p58_payoff_function_with_graph.R


s<-seq(10,50,by=5)# stock prices

k<-30             # exercise price

n<-length(s)

payoff<-rep(0,n)  # initialization 

for (i in 1:n) {
   payoff[i]=max(0,s[i]-k)
}

plot(s,payoff,type="l")
