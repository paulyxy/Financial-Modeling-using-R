#  c02_p57_payoff_call_with_comments.R


payoff_call<-function(sT,x){

" 
Objective: payoff function of a European call option 
       sT: stock price at maturity day T
        x: exercise price
 
     e.g., > payoff_call(45,30)
          [1] 15
"

t<-(sT-x)

return((t+abs(t))/2)

}
