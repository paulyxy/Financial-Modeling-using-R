#  c03_p60_profit_loss_call.R

sT<-seq(10,50,by=5)# prices

k<-30     # exercise 

c<-2      # option price

n<-length(sT)

profit<-rep(0,n)

for (i in 1:n) {
   profit[i]=max(0,sT[i]-k)-c
}

plot(sT,profit,type="l")


