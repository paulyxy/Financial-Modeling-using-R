#  c02_p56_payoff_call.R

payoff_call<-function(sT,x)(sT-x+abs(sT-x))/2