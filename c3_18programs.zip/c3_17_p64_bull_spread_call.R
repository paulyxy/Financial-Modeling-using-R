#  c03_p64_bull_spread_call.R


bull_spread_call<-function(x1=50,x2=52,T=1,r=0.05,sigma=0.3){
" 

buy call(x1) and sell call (x2) with x1<x2


"

  s<-(x1-3):(x2+2) # stock prices

  s0<-mean(s)      # s0: today price   

  n<-length(s)

  call_1<- s-x1

  call_2<- s-x2

  for(i in 1:n){
     call_1[i]<-max(call_1[i],0)
     call_2[i]<-max(call_2[i],0)
  }

  cost<-bs_f('C',s0,x1,T,r,sigma)-

  bs_f('C',s0,x2,T,r,sigma)

  bull_spread<-call_1 - call_2 - cost

  plot(s,bull_spread,type='l')

}

