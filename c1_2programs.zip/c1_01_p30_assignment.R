"
  Name     : c1_01_p30assignment.R
  Book     : Financial Modeling using R (2018)
  Author   : Yuxing Yan
  ISBN     : 9-78-1-94696454
  Publisher: Legaia Books 
  Amazon   : http://canisius.edu/~yany/amazonR2018.shtml
  Date     : 3/7/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"

 x<-10           # assign 10 to x

 y=20            # assign 20 to y

 30 ->z          # assign 30 to z

 title<-"Hello"  # title is a character (string) variable 

