"
  Name     : c1_02_p30_semicolon.R
  Book     : Financial Modeling using R (2018)
  Author   : Yuxing Yan
  ISBN     : 9-78-1-94696454
  Publisher: Legaia Books 
  Amazon   : http://canisius.edu/~yany/amazonR2018.shtml
  Date     : 3/7/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"

# semi-colon (;) can be used to separate different lines 

 fv<-10; pv<-100; n<-10; rate<-0.05
