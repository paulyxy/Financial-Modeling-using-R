#c7_p124_Sharpe_ratio.R


load("retDIBM.RData")

rf_daily<-(1+EDM1[,2])^(1/30)-1

rf<-data.frame(EDM1[,1],rf_daily)

colnames(rf)<-c("date","rf")   # try if omit this line

a<-merge(ibm,sp500,by="date")  # merge 3 data sets

x<-merge(a,rf,by="date")

t<-x$ret-x$rf

mean(t)/sd(t)                  # Sharpe ratio
