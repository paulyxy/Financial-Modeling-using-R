#c7_p122_generate_ffMonthly_RData.R


x<-read.table("F-F_Research_Data_factors.txt",skip=4,nrow=10)

colnames(x)<-c("yyyymm","mkt_rf","SMB","HML","Rf")



x<-read.table("F-F_Research_Data_factors.txt",skip=4,nrow=1014)


x<-read.table("F-F_Research_Data_factors.txt",skip=4,nrow=1014)


 colnames(x)<-c("date","mkt_rf","SMB","HML","Rf")

 x[,2:5]<-x[,2:5]/100 # from percent to decimal

 ff_monthly_factors<-x # use a better name

 save(ff_monthly_factors,file="ff_monthly_factors.RData")