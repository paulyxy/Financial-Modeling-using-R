#c7_p122_2_annual_beta.R

 source("http://canisius.edu/~yany/Beta.R")

 Beta("C",2010)
  
  
