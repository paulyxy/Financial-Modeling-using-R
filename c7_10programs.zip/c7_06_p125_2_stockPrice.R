#c07_p125_2_stock_price.R


# - Generate date and prices ��- #

n<-100 # number of stock prices

date<-1:n

T<-1 # maturity date in years

rf<-0.03 # risk-free rate

S<-20 # stock price at time 0

sigma<-0.1 # volatility of the underlying security

set.seed(12345)

price<-Stock_price(S,rf,T,n,sigma)

x<-cbind(date,price)

