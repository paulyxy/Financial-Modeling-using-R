#c7_p122_run_ff3factorModel.R


load("retD50.RData")

load("ff_daily_factors.RData")

stock<-"C"       # C for Citigroup

year<-2010       # year we are interested

y<-yahoo_daily   # simplify the notation

f<-ff_daily_factors # simplify the notation

a<-subset(y,y[,1]==stock & as.integer(y[,2]/10000)==year)

b<-subset(f,as.integer(f[,1]/10000)==year)

a2<-cbind(a[,2],a[,9])             # only choose date and return

colnames(a2)<-c("date","return")   # assign column names

k<-merge(a2,b,by="date")           # merge by date

y<-k$return-k$Rf                   # dependent variable

x<-cbind(k$mkt_rf,k$SMB,k$HML)     # independent variables

lm(y~x)                            # lm() for linear model