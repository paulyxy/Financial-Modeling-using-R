#c07_p123_3daysHigh.R

# �- estimate 3-day high ���- #
y<-matrix(0,n-3,3)
for(i in 4:n){
j<-i-3
y[j,1]<-x[i,1] # date variable
y[j,2]<-max(x[i,2]) # price at t
y[j,3]<-max(x[(i-3): (i-1),2]) # high over the last 3 days
}
We print the first several lines