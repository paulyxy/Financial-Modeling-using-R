#c07_p127_loop.R

ticker<-"IBM"

final<-NA

for(i in 1970:2010) {

       final[i-1970+1]<-Beta(ticker,i)

}