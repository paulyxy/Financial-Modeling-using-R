#c7_p119_lm.R



set.seed(123)

 x1<-seq(1,10,by=0.2)

 n<-length(x1)

 x2<-10 + runif(n)

 x3<-runif(n)

 x<-cbind(x1,x2,x3)

 y<-2+3*x1-x2+5*(x3)+rnorm(n)

 lm(y~x)