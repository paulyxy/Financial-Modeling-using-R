#c07_p125_stock_price.R

Stock_price<-function(S,r,T,n,sigma){

   delta_T<-T/n

   ST<-seq(1:n)*0

   ST[1]<-S
 
   for (i in 2:n)
        ST[i]<-ST[i-1]*exp((r-0.5*sigma*sigma)*delta_T+sigma*rnorm(1)*sqrt(delta_T))
 
   return(ST)
}