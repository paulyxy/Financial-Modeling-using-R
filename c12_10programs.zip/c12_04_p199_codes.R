# c12_199_codes.R

 library(quantmod)
 library(XML)
 source("c:/credit.txt")
 z_score("DELL")