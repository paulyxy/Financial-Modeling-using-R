# c12_191_package_XML.R

 library(XML)

 readHTMLTable("http://finance.yahoo.com/bonds/composite_bond_rates")[[4]][,1:2]