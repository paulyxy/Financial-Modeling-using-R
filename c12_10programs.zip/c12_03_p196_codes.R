# c12_196_codes.R

 
 rm(list=ls())
 load("c:/temp/credit.RData")
 ls()/bonds/composite_bond_rates")