# c12_194_codes.R

 
 library(XML)

 readHTMLTable("http://finance.yahoo.com/bonds")[[2]][1:2]


library(XML)

x<-readHTMLTable("http://finance.yahoo.com/bonds/composite_bond_rates")