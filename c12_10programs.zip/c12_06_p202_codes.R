# c12_202_codes.R




f <- function(x) 7+x^2

nlm(f, 10) # 10: starting value


f <- function(x, a) 7+x^2
t(nlm(f, 10))


f <- function(x, a) 7+(x-a)^2
t(nlm(f, 10, a=10.5)) # 10 is an initial value