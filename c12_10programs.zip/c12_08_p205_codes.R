# c12_205_codes.R

library(CreditMetrics)

load("c:/temp/credit.RData")

loss_given_default<- 0.45

 cm.cs(one_year_migration,loss_given_default)

 round(cm.cs(one_year_migration, loss_given_default)*10000,digit=2)


 t(one_year_migration[,8])