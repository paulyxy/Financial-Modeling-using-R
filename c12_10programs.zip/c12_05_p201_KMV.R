# c12_201_KMV.R



KMV<-function(E,D,T,r,sigmaE){

   n<-1000
   m<-100

   for(i in 1:n){
       for(j in 1:m){

         A<-E+D/2+i*D/n
         sigmaA<-0.05+j*(0.5-0.05)/m
         d1 = (log(A/D)+(r+sigmaA*sigmaA/2.)*T)/(sigmaA*sqrt(T))
         d2 = d1-sigmaA*sqrt(T)
         diff1<- A*pnorm(d1)-D*exp(-r*T)*pnorm(d2)-E
         diff2<- A/E*pnorm(d1)*sigmaA-sigmaE

         if(i+j==2){
             diff<-abs(diff1) + abs(diff2)
             final<-c(A,sigmaA,diff)
         }else{
             if(abs(diff1)+abs(diff2)<diff){
                 diff<-abs(diff1) +abs(diff2)
                 final<-c(A,sigmaA,diff)
               }
         }
      }
   }
   return(final=round(final,digits=4))
}



# KMV(D=64062,E=110688,T=1,r=0.07,sigmaE=0.4)


