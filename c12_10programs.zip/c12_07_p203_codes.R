# c12_202_codes.R


E=3
D=10
T=1
r=0.05
sigmaE=0.4

a<-c(E,D,T,r,sigmaE)


KMV_f<-function(x,a){
   " nlm(f,x<-c(D,sigmaE),a) ->y
     y$estimate
    [1] 12.51195139 0.09608728 (correct)
  "

  A<-x[1]
  sigmaA<-x[2]
  E<- a[1]
  D<- a[2]
  T<- a[3]
  r<- a[4]
  sigmaE<-a[5]

  d1 = (log(A/D)+(r+sigmaA*sigmaA/2.)*T)/(sigmaA*sqrt(T))
  d2 = d1-sigmaA*sqrt(T)
  diff1<- A*pnorm(d1)-D*exp(-r*T)*pnorm(d2)-E
  diff2<- A/E*pnorm(d1)*sigmaA-sigmaE
  return(abs(diff1)/E + abs(diff2)/sigmaE)


}


#nlm(KMV_f,x<-c(E/2+D,sigmaE),a)$estimate