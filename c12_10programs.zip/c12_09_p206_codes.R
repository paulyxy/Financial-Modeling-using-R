# c12_206_codes.R


library(CreditMetrics)

load("c:/temp/credit.RData")

rf <- 0.03 # risk-free rate

values <- c(4, 1, 10)*1e6 # credit values

rating <- c("BBB","AA","B")

loss_give_default<- 0.45

x<-cm.ref(one_year_migration,loss_given_default,values,rf,rating)



