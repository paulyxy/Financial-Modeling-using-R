# c12_207_codes.R



library(CreditMetrics)

load("c:/temp/credit.RData")

n <- 50000 # number of random numbers

rf <- 0.03 # risk-free rate

values <- c(4, 1, 10)*1e6 # credit values

LGD<- 0.45 # LGD: loss given default

rating <- c("BBB","AA","B") # rating of three firms

alpha <- 0.99 # confidence level

firmnames <- c("f1","f2","f3") # three names

rho <-matrix(c( 1, 0.4, 0.6, 0.4, 1, 0.5,0.6, 0.5, 1),3,3,dimnames=list(firmnames,firmnames),byrow = TRUE)

N<-length(values)

cm.CVaR(one_year_migration,LGD,values,N,n,rf,rho,alpha,rating)

