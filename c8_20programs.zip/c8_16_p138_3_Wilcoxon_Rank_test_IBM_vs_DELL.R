#c08_p138_2_Wilcoxon_Rank_test_IBM_vs_DELL.R



wilcox.test(ret_IBM[1:504],ret_DELL[1:504],paired=TRUE)