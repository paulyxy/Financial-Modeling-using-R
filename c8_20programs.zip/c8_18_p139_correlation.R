# c08_p139_correlation.R



 x<-c(2.6,2.7,7.8)

 y<-c(10.4,3.5,0.6)

 cor(x,y)


 cor(x,y,method='spearman')