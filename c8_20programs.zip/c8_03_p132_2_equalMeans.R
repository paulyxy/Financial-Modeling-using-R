#c08_p132_2_equalMeans.R

 data(sleep)

 oneway.test(extra ~ group, data = sleep)