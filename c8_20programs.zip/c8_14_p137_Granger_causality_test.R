#c08_p137_Granger_causility_test.R

library(lmtest)

data(ChickEgg)

dim(ChickEgg) # [1] 54 2

ChickEgg[1:10,]

grangertest(egg ~ chicken, order = 3, data = ChickEgg)


