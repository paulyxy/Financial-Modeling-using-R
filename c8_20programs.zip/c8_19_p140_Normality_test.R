# c08_p139_correlation.R



 set.seed(12345)

 x<-rnorm(1000)

 mean(x)


 shapiro.test(x)