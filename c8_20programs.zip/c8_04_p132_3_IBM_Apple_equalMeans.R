#c08_p132_3_IBM_Apple_equalMeans.R

x<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)

n<-nrow(x)

ret<-data.frame(as.Date(x[1:(n-1),1]),(x[1:(n-1),7]-y[2:n,7])/x[2:n,7])

y<-read.csv("http://chart.yahoo.com/table.csv?s=AAPL",header=T)

n<-nrow(y)

ret2<-data.frame(as.Date(y[1:(n-1),1]),(y[1:(n-1),7]-y[2:n,7])/y[2:n,7])

t.test(ret,ret2)