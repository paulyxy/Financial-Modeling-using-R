#c08_p131_Ttest.R

y<-read.csv("http://chart.yahoo.com/table.csv?s=AAPL",header=T)

n<-nrow(y)

ret<-(y[1:(n-1),7]-y[2:n,7])/y[2:n,7]

t.test(ret,mu=0.000113)


