#c08_p133_2_F_test.R


 t<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)

 n<-nrow(t)

 ret<-(t[1:(n-1),7]-t[2:n,7])/t[2:n,7]

 x<-ret[1:as.integer(length(ret)/2)]

 y<-ret[as.integer(length(ret)/2):length(ret)]

 var.test(x,y)


