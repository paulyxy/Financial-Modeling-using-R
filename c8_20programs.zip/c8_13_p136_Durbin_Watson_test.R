#c08_p136_Durbin_Watson_test.R

library(lmtest)

 y<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)

 n<-nrow(y)

 ret<-(y[1:(n-1),7]-y[2:n,7])/y[2:n,7]

 m<-as.integer(length(ret)/2)

 x<-rep(c(-1,1),m)

 dwtest(ret[1:(2*m)]~x)