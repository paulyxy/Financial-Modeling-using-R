#c08_p134.R

 x <- rnorm(500,mean = 0, sd = 0.5)

 y <- rnorm(1000,mean = 0.5,sd =0.2)

 var.test(x,y,ratio=0.5^2/0.2^2)