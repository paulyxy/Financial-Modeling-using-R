#c08_p135_autoCorrelation.R

 d<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)

 n<-nrow(d)

 ret<-(d[1:(n-1),7]-d[2:n,7])/d[2:n,7]

 cor(ret[2:(n-1)],ret[1:(n-2)])