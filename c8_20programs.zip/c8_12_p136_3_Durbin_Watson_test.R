#c08_p136_2_ Durbin_Watson_test.R

set.seed(123)

ma<- rnorm(100) # rho=0 (white noise)

x <- rep(c(-1,1), 50)

rho<- 0.4

ma2 <- filter(ma, rho, method="recursive")

y2 <- 1 + x + ma2

dwtest(y2 ~ x) 

# DW = 1.2856, p-value = 0.0002256