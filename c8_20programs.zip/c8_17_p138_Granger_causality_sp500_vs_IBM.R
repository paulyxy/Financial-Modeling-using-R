#c08_p137_Granger_causility_sp500_vs_IBM.R

d<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)[,7]

n<-length(d)

ret<-(d[1:(n-1)]-d[2:n])/d[2:n]

rm(d,n)

d2<-read.csv("http://chart.yahoo.com/table.csv?s=^GSPC",header=T)[,7]

n2<-length(d2)

mkt<-(d2[1:(n2-1)]-d2[2:n2])/d2[2:n2]

ret_mkt<-data.frame(cbind(ret[1:500],mkt[1:500]))

colnames(ret_mkt)<-c("ret","mkt")

grangertest(ret ~ mkt, order = 1, data = ret_mkt)