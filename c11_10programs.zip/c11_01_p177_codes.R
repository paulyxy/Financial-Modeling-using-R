# c11_p177_codes.R


 x<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)

 100*x[1,5]

 n_shares<-100
 n_days<-10
 x<-read.csv(http://chart.yahoo.com/table.csv?s=IBM",header=T)
 position<-n_shares*x[1,5]
 n<-nrow(x)
 ret<-(x[1:(n-1),7]-x[2:n,7])/x[2:n,7]
 mu<-(mean(ret)+1)^n_days-1
 VaR<-position*(mu-2.33*sd(ret)*sqrt(n_days))
 VaR

