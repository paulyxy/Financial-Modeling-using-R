# c11_188_codes.R



 library(PerformanceAnalytics)
 n_shares<-100
 x<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)
 position<-n_shares*x[1,5]
 n<-nrow(x)
 ret<-(x[1:(n-1),7]-x[2:n,7])/x[2:n,7]
 position*(mean(ret)-2.33*sd(ret))