# c11_187_codes.R


 library(PerformanceAnalytics) # load the package
 data(edhec) # load the data set
 colnames(edhec)

 edhec[1,]


 VaR(edhec[,1], p=.95, method="historical")


 y<-data.frame(as.numeric(edhec[,1]))

 n<-as.integer(0.05*nrow(y)+0.5)

 y[order(y),1][n]

 method = c("modified","gaussian","historical","kernel"),
 VaR(edhec[,1],p=.95, method="historical")

 VaR(edhec[,1], p=.95, method="gaussian")

 VaR(edhec[,1], p=.95, method="modified")

