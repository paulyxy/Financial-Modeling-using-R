# c11_p184_codes.R


 set.seed(12345)

 kurtosis(rnorm(500000))



 library(PerformanceAnalytics)
 n_shares<-100
 confident<-0.99
 x<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)
 position<-n_shares*x[1,5]
 n<-nrow(x)
 ret<-(x[1:(n-1),7]-x[2:n,7])/x[2:n,7]

 S<-skewness(ret) 
 K<-kurtosis(ret) 


sigma<-sd(ret)
 z<-abs(qnorm(1-confident))
 a<-z+1/6*(z^2-1)*S +1/24*(z^3-3*z)*K -1/36*(2*z^3-5*z)*S^2
 mVaR<-position*(mean(ret)-a*sigma)
 mVaR