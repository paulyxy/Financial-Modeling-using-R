# c11_p178_codes.R


 x<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)

 n<-nrow(x)

 ret<-(x[1:(n-1),7]-x[2:n,7])/x[2:n,7]

 mean(ret)/(2.33*sd(ret))

 mean(ret)/(mean(ret)+2.33*sd(ret))


