# c11_p183_codes.R

 n_shares<-100
 confidence<-0.99
 x<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)
 position<-n_shares*x[1,5]
 n<-nrow(x)
 ret<-(x[1:(n-1),7]-x[2:n,7])/x[2:n,7]
 VaR2<-position*(mean(ret)+qnorm(1-confidence)*sd(ret))
 VaR2



# --------------------


 library(PerformanceAnalytics)
 set.seed(100)
 x<-rnorm(50000)
 mean(x)

 sd(x)

 skewness(x)

 kurtosis(x)



