# c11_p179_codes.R


 x<-seq(-4,4,length=500)

 y<-1/sqrt(2*pi)*exp(-x^2/2)

 plot(x,y,type="l",lwd=2,col="red")

# 'l' is the lower case letter of L

# lwd: line widths for the axis line

# and the tick marks


# ---------------------------------------------


x<-seq(-4,4,length=200)

y<-dnorm(x,mean=0,sd=1)

plot(x,y,type="l",lwd=2,col="red")

x<-seq(-4,-2.33,length=200)

y<-dnorm(x,mean=0,sd=1)

polygon(c(-4,x,-2.33),c(0,y,0),col="gray")

