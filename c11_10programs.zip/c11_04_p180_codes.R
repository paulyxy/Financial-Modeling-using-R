# c11_p180_codes.R

 confident<-0.99

 LeftTail<-1-confident

 qnorm(1-confident)


 qnorm(LeftTail)




position<-1500 # dollar
x<-read.csv("http://chart.yahoo.com/table.csv?s=DELL",header=T)
n<-nrow(x)
ret<-(x[1:(n-1),7]-x[2:n,7])/x[2:n,7]
VaR<-position*(mean(ret)-2.33*sd(ret))
VaR 



