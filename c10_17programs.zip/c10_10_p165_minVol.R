# c10_p164_minVol.R


portfolio_vol<-function(ret_matrix,weight){

   m<-ncol(ret_matrix)
   m2<-length(weight)
 
   if(m!=m2) stop(" dimensions are not matched!!!")

   COV<-cov(ret_matrix)

   sum<-0
   for(i in 1:m)
       for(j in 1:m)
          sum<-sum + weight[i]*weight[j]*COV[i,j]

   return(sqrt(sum))
}



