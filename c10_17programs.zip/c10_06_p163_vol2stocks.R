# c10_p163_vol2stocks.R


portfolio_vol_2stocks<-function(ret_matrix,weight_1){
   x1<-weight_1
   x2<-1-x1
   std1<-sd(ret_matrix[,1])
   std2<-sd(ret_matrix[,2])
   return(x1^2*std1^2 +x2^2*std2^2+2*x1*x2*cov(ret_matrix[,1],ret_matrix[,2]))
}