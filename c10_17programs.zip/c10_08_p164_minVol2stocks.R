# c10_p164_minVol2stocks.R


min_vol_2stocks<-function(ticker1,ticker2){

   x<-get_ret(ticker1)
   y<-get_ret(ticker2)
   s1<-sd(d[,2])
   s2<-sd(d[,3])

   rho<-cor(d[,2],d[,3])

   d<-merge(x,y)
   w<-seq(0,1,by=0.01)
   vol<-port_vol2stocks(s1,s2,rho,w)
   k<-cbind(w,vol,s1,s2,rho)
   f<-round(matrix(k[k[,2]==min(vol),],1,5),digits=4)

   colnames(f)<-colnames(f)<-c(paste(ticker1,"_weight",sep=""),"port_vol",paste(ticker1,"_vol",sep=""),paste(ticker2, "_vol",sep=""),"rho")
   return(f)
}


get_ret<-function(ticker){
   x<-read.csv(sub("$V",ticker,'http://chart.yahoo.com/table.csv?s=$V' ,fixed=T))
   n<-nrow(x);ret<-(x[1:(n-1),7]-x[2:n,7])/x[2:n,7]
   d<-data.frame(as.Date(x[1:(n-1),1]),ret)
   colnames(d)<-c("date",ticker); return(d[1:504,])
}


