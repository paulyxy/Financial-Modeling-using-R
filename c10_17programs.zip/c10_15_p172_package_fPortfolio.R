# c10_p172_package_fPortfolio.R


library(fPortfolio)

d<-SMALLCAP.RET

d2<-d[, c("BKE","GG","GYMB","KRON ")]

spec = portfolioSpec()

setSolver(spec) = "solveRquaprog"

setTargetReturn(spec) = mean(d2)

constraints = "LongOnly"

solution<-solveRquadprog(d2, spec, constraints)
