# c10_p171_2_package_PortRisk.R

library(PortRisk)

data(SnP500Returns)

stocks <- c("AAPL","IBM","INTC","MSFT")

w <- c(10000,40000,20000,30000)

begdate<-"2013-01-01"

enddate<- "2013-01-31"

risk.attribution(tickers=stocks,weights=w,start=begdate,end =enddate,data=SnP500Returns)



