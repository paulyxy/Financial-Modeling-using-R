# c10_p174_minVariancePort.R


library(fPortfolio)

d<-SMALLCAP.RET

d2<-d[, c("BKE","GG","GYMB","KRON")]

f<-portfolioFrontier(data)

frontierPlot(f,pch=19,xlim=c(0,0.25), ylim=c(0,0.035))

grid()

abline(h = 0, col = "grey")

abline(v = 0, col = "grey")

minvariancePoints(f,pch=19,col="red")
