# c10_p167codes.R


std1<-sqrt(0.0036)
std2<-sqrt(0.0576)
rho<- -1
x1<-seq(0,1,0.01)
x2<-1-x1
var_p<-x1^2*std1^2 + x2^2*std2^2 +2*x1*x2*rho*std1*std2
final<-cbind(x1,x2,var_p)
final2<-final[order(final[,3]),]