# c10_p171_package_portfolio.R


library(portfolio)

data(dow.jan.2005)

dim(dow.jan.2005)

data(SnP500List)

head(SnP500List)