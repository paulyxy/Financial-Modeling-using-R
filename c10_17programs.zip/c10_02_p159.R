# c10_p159.R



 var(1:10)

 sd(1:10)


# ---------------------------

vol_stock<-function(ticker,date1,date2){

    t<-'http://chart.yahoo.com/table.csv?s=$V'

    x<-read.csv(sub("$V",ticker,t ,fixed=T))

    n<-nrow(x)

    ret<-(x[1:(n-1),7]-x[2:n,7])/x[2:n,7]

    d<-data.frame(as.Date(x[1:(n-1),1]),ret)

    colnames(d)<-c("date","ret ")

    vol_daily<- sd(subset(d[,2],d[,1]>=date1 & d[,1]<=date2))

    return(vol_daily*sqrt(252))
}

