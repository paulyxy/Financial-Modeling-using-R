# c10_p162_merge.R


 x<-c(1,2,3,4,5,6)
 y<-c(1,2.,3,4.6)
 x2<-matrix(x,3,2)
 y2<-matrix(y,2,2)
 colnames(x2)<-c("id","value1")
 colnames(y2)<-c("id","value2")

 merge(x2,y2)

 merge(x2,y2,all.x=T)