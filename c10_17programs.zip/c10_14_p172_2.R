# c10_p172_2.R

require(fPortfolio)

require(tseries)

d<-SMALLCAP.RET[,c("BKE","GG","GYMB","KRON")]

k<-portfolio.optim(d)

k$pw



# complete format
portfolio.optim(x, pm = mean(x), riskless = FALSE,shorts = FALSE,
rf = 0.0, reslow = NULL, reshigh = NULL,covmat = cov(x), �)