# c10_p158_vol2stocks.R


vol2stocks<-function(sigma1,sigma2,rho,weight_1){
   
   x1<-weight_1

   x2<-1-x1

   var<-x1^2*sigma1^2 +x2^2*sigma2^2+2*x1*x2*rho*sigma1*sigma2

   return(sqrt(var))

}


# ----------------------------

 vol2stocks(0.1,0.2,-0.3,0.1)

 vol2stocks(0.1,0.2,0.3,0.1)

 rho<-seq(-0.2,0.5,by=0.01)

 vol<-vol2stocks(0.3,0.2,rho,0.5)

 plot(rho,vol)