# c10_p160.R


 date1<-as.Date("2001-01-01")

 date2<-as.Date("2001-01-20")

 vol_stock(IBM",date1,date2)