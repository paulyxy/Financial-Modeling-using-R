# c10_p161_yahooMonthlyRet.R

yahooMonthlyRet<-function(ticker){

   ticker<-toupper(ticker)
   k1<-paste('http://ichart.finance.yahoo.com/table.csv?s=',ticker,sep='')
   k2<-'&amp;a=01&amp;b=01&amp;c=1962&amp;d=31&amp;e=12&amp;'
   k3<-'f=2015&g=m&amp;ignore=.csv'
   k<-paste(k1,k2,k3,sep='')
   x<-read.csv(file=k,header=T)
   name<-colnames(x)
   p<-x[,7]
   n<-nrow(x)
   ret<-(p[1:(n-1)]-p[2:n])/p[2:n]
   d<-data.frame(as.Date(x[1:(n-1),1]),x[1:(n-1),7],ret)
   colnames(d)<-c('Date','Price','Ret')
   return(d)
}


# -------------

begdate<-as.Date("2006-01-01")
enddate<-as.Date("2010-12-01")
stocks<-c("IBM","C","MSFT","DELL")
d<-yahooMonthlyRet("^GSPC") # ^GSPC is S&P500
base<-subset(d,d[,1]>=begdate & d[,1]<=enddate)
rm(d)
for(i in 1:length(stocks)){
   d<-monthly_ret(stocks[i])
   base<-merge(base,d)
}


