# c10_p173_codes.R


library(fPortfolio)

begdate<-as.Date("1978-01-01")
enddate<-as.Date("2009-12-01")

source("http://canisius.edu/~yany/R/yahooMonthlyRetTickerAsRet.R")

stock1<-yahooMonthlyRetTickerAsRet("IBM")    # 1st stock
stock2<-yahooMonthlyRetTickerAsRet("DELL")   # 2nd stock

sp500 <-yahooMonthlyRetTickerAsRet("^GSPC")  # market index

d<-merge(stock1,stock2)
d2<-subset(d,d[,1]>=begdate & d[,1]<=enddate)
d3<-as.timeSeries(merge(d2,sp500))

data<-d3[,1:2]

factors<-d3[,3]

attr(data, "factors") <- factors

tailoredFrontierPlot(portfolioFrontier(data))#Long-only Markow M



