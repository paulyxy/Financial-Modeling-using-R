# c06_p117_portfolio_beta.R


load("c:/temp/prcM50.RData")  # use c:/temp instead of c:/yahoo_daily

a<-prcM50

s<-c("IBM","MSFT","DELL")

shares<-c(10,5,2)

value_port<-0

j<-1

value_port<-0

for(i in s){ 

    k<-subset(a,a[,1]==i & a[,2]=="2002-12-31")

    print(k)

    value_port<-value_port+shares[j]*k[,6]

    j<-j+1

}

value_port

