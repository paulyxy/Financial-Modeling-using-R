# c06_p1112_CAPM_no_riskfree.R

# without using Rf in the regression
 load("retDIBM.RData")

  t<-yahoo_daily                # simplify the notation 

  ibm<-subset(t,t[,1]==  "IBM" & format(t[,2],"%Y")=="2010")

  ind<-subset(t,t[,1]=="^GSPC" & format(t[,2],"%Y")=="2010")

  a<-data.frame(ibm[,2],ibm[,9]) 

  colnames(a)<-c("date","Ri")

  b<-data.frame(ind[,2],ind[,9])
  colnames(b)<-c("date","Mkt")
  k<-merge(a,b,by="date")        # merge by date

   y<-k$Ri                       # get dependent variable

   x<-k$Mkt                      # get independent variable

   lm(y~x)                       # lm() for linear model


