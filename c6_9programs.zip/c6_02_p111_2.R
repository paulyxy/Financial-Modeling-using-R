# c06_p1111_2_percentage_ret.R


 p<-c(10.0,10.02,9.90,10.30)     

 n<-length(p)

 ret<-(p[2:n]-p[1:(n-1)])/p[1:(n-1)] 

 ret

