# c06_p114_2_annual_beta.R


load("retDIBM.Rdata")

stock<-data.frame(IBM$Date,IBM$Return)

colnames(stock)<-c("Date","Ret")

ind<-data.frame(sp500$Date,sp500$Return)

colnames(ind)<-c("Date","mkt")

x<-merge(stock,ind)

final<-merge(x,EDM1,x1="Date",x2="date")

years<-unique(as.integer(format(final[,1],"%Y")))

for(i in years[1:5]){ # for the first 5 years

    t<-subset(final,format(final[,1],"%Y")==i)
    a<-t$ret-t$EDM1
    y<-a$ret-a$EDM1

    cat("year=",i, "beta=",coef((lm(y~x)))[2], "\n")
}