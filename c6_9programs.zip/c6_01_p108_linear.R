# c06_p108_linear.R

 set.seed(123) 

 x<-seq(1,10,by=0.2)

 n<-length(x)

 y<-2+3*x + rnorm(n)

 plot(x,y)


 lm(y~x)