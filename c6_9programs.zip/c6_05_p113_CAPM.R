# c06_p113_CAPM.R

beta<-function(ticker,beg_year,end_yer,d_or_m){

   d<-yahoo_price(ticker,beg_year,end_yer,d_or_m)
   stock<-data.frame(d[,2],d[,9])
   colnames(stock)<-c('date','return')
   d2<-yahoo_price("^GSPC",beg_year,end_yer,d_or_m)
   index<-data.frame(d2[,2],d2[,9])
   colnames(index)<-c('date','mkt_ret')
   z<-merge(stock,index,by="date")
   print(lm(z$return~z$mkt_ret))
   print(' beta will be z$mkt_ret')

}
