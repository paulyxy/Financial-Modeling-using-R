# c06_p114_moving_beta.R



load("c:/temp/prcM50.RData")    # a littble differnt from the book 

a<-prcM50                       # make it simpler to use the data set 

s<-c("IBM","MSFT","DELL")       # three stocks

for(i in s){ 

    k<-subset(a,a[,1]==i & a[,2]=="2002-12-31")

    print(k)

}
