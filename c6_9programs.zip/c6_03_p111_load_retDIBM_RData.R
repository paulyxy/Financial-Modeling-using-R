# c06_p1111_load_retDIBM_RData.R

con<-url("http://canisius.edu/~yany/RData/retDIBM.RData")

load(file=con)

close(con)


 head(IBM)

 head(EDM1)

