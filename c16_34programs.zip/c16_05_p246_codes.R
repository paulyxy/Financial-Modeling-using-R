# c16_p246_codes.R



 library(quantmod)

 getFinancials("AAPL")

 x<-viewFin(AAPL.f,"IS","A")

 dim(x)

 head(x)

 tail(y)