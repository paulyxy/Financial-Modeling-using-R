# c16_p245_246_package_fImport.R

 library(fImport)

 head(nyseListing,2)

 dim(nyseListing)



 require(quantmod)
 getSymbols('ibm',src='yahoo')

 x<-dailyReturn(IBM)
 head(x,2)
 tail(x,2)

# -----------------------------

 y<-cbind(x,Lag(x),Next(x))
 head(y,2)