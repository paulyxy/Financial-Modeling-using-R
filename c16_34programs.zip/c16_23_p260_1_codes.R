# c16_p260_1_codes.R


library(fAssets)

price<- 100/12 * assetsSim(n = 120, dim = 4)

cum_price<-apply(price,2,FUN = cumsum)

ts.plot(prices,col = 1:4,ylim = c(-300, 300))


# ------------


 library(fAssets)
 weight<-rep(1/4, 4)
 price<- 100/12 * assetsSim(n = 120, dim = 4)
 cum_price<-apply(price,2,FUN = cumsum)
 alpha = 0.10
 pfolioVaR

# Conditional Value at Risk Plus:
 pfolioCVaRplus(cum_price,weight, alpha)