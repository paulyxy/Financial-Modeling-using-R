# c16_p255_256_package_timeDate.R

 library(timeDate)

 Sys.timeDate()

 x<-"2011-12-28 20:20:10"

 timeDate(x)

 timeDate(x)+4


# -------------------

 library(timeDate)

  x<-listFinCenter("Asia")
 
  length(x)

  head(x,5)

  tail(x,3)

# ------------------

  holidayNYSE(2011)