# c16_p255_1_creditVaR.R

 library(CreditMetrics)

 n_firm <- 3

 ead <- c(4000000, 1000000, 10000000)

 rating <- c("BBB","AA","B")

 firmnames <- c("firm 1","firm 2","firm 3 ")

 rf <- 0.03

 rc <- c("AAA","AA","A","BBB","BB","B","CCC","D")

 loss_given_default <- 0.45

 alpha <- 0.99 # confidence level

 n <- 50000 # number of simulations

 rho<-matrix(c( 1, 0.4, 0.6,0.4, 1, 0.5,0.6,0.5,1),3,3,dimnames=list(firmnames, firmnames),byrow = TRUE)

 cm.CVaR(M,loss_given_default,ead,n_firm,n,rf,rho,alpha,rating)






