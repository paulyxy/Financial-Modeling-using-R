# c16_p249_250_package_fExoticOptions.R


 library(fExoticOptions)

 GeometricAverageRateOption(TypeFlag="p",S = 80,X = 85,Time = 0.25, r = 0.05, b = 0.08,sigma= 0.2)


# ------------------------------


 LevyAsianApproxOption(TypeFlag = "c",S = 100, SA = 100, X = 105,Time = 0.75,time = 0.5, r = 0.1, b = 0.05, sigma = 0.15)



 SoftBarrierOption(TypeFlag = "cdo",S = 100, X = 100, L = 70,U = 95, Time = 0.5, r = 0.1, b = 0.05, sigma = 0.2)



