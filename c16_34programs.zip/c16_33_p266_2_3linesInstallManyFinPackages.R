# c16_p266_2_3linesInstalManyFinPackages.R

install.packages("ctv")

library("ctv")

install.views("Finance")