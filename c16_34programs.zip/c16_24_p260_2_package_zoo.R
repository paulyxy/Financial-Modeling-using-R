# c16_p260_2_package_zoo.R


 library(zoo)

  x <- c(NA, 6,2, 4, 6,NA)

  na.trim(x)


 x<-c(NA,NA,1,NA,2,NA,4,NA,10,NA)

 x2<-na.fill(x,"extend")

 x2



