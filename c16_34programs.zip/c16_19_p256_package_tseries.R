# c16_p256_package_tseries.R


 require(tseries)

 require(quantmod)

 getSymbols('ibm',src='yahoo')

 x<-dailyReturn(IBM)

 adf.test(x)



