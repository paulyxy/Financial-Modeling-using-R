# c16_p257_codes.R


 library(quantmod)

 getSymbols("IBM",src='yahoo')

 x<-dailyReturn(IBM)

 jarque.bera.test(x)

 require(tseries)
 x<-c(100,20,NA)
 y<-na.remove(x)

require(tseries)
require(quantmod)
getSymbols('ibm',src='yahoo')
x<-dailyReturn(IBM)


require(tseries)
require(quantmod)
getSymbols('ibm',src='yahoo')
x<-dailyReturn(IBM)
x2 <- ts(x[1:252])
out<-garch(x2,c(0,1))

out


