# c16_p263_2_package_stockPortfolio.R


require(stockPortfolio)

data(stock94)

data(stock99)

data(stock94Info)

sim1 <- stockModel(stock94, model='SIM', industry=stock94Info$industry, index=25)
