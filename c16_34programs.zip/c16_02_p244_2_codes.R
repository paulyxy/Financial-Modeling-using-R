# c16_p244_2_codes.R

 library(fImport)

 x<-fredSeries("DPRIME") # DPRIME for daily prime rate


 library(fImport)
 y<-fredSeries("MPRIME")
 head(y)

library(fImport)
x<-yahooSeries('IBM',nDaysBack=500)
n<-nrow(x)
ret<-(x[1:(n-1),6]-x[2:n,6])/x[2:n,6]


library(fImport)
x<-yahooSeries('IBM',nDaysBack=500)
n<-nrow(x)
p<-x[,6]
rownames(p)<-1:n
ret<-(p[1:(n-1)]-p[2:n])/p[2:n]