# c16_p261_package_TTR.R


 library(TTR)

 x <- getYahooData("IBM",19990404, 20050607)
 
 head(x,3)



# library(TTR)

  x <- getYahooData("IBM")

  tail(x[,1:4],3)


# ROC(x, n=1, type=c("continuous","discrete"), na.pad=TRUE)

# library(TTR)

 x<-read.csv("http://chart.yahoo.com/table.csv?s=IBM",header=T)

 head(x,3)



