# c16_p263_codes.R


set.seed(12345)
x <- runif(100)
n<-500
d<-bootstrap_f(x,n)


library(ttrTests)
data(spData)
rc <- dataSnoop(spData,bSamples=3,test="RC")
spa <- dataSnoop(spData,bSamples=3,test="SPA")


