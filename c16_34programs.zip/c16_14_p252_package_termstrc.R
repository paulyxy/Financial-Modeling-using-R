# c16_p252_package_termstrc.R

  library(termstrc)

  data(govbonds)
 
  typeof(govbonds)

  length(govbonds)

  data(govbonds)

  cf <- create_cashflows_matrix(govbonds[[1]])

  dim(cf)

  cf_p[1:5,1:5]


 data(govbonds)

 cf <- create_cashflows_matrix(govbonds[[1]])

 m <- create_maturities_matrix(govbonds[[1]])

 beta <- c(0.0511,-0.0124,-0.0303,2.5429)

 bond_prices(method="ns",beta,m,cf)$bond_prices


data(govbonds)
cf_p=create_cashflows_matrix(govbonds[[1]],include_price=TRUE)
m_p=create_maturities_matrix(govbonds[[1]],include_price=TRUE)
bond_yields(cf_p,m_p)
