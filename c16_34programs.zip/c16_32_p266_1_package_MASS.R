# c16_p266_1_package_MASS.R

 library(MASS)

 length(SP500)

 head(SP500)


#------------------

 library(MASS)
 set.seed(123)
 x<-rnorm(10000)
 fitdistr(x,"normal")

