# c16_p263_3_package_XML.R


 library(XML)

 readHTMLTable("http://finance.yahoo.com/bonds")[[2]][,1:2]


 f = system.file("exampleData","mtcars.xml",package="XML")

 f

 x<-xmlParseDoc(f)

