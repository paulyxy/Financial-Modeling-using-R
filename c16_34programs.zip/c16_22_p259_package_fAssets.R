# c16_p259_260_package_fAssets.R



 library(fAssets)

 dim(LPP2005REC)



 head(LPP2005REC,2)

 x <-as.timeSeries(data(LPP2005REC))[, 1:2]

 head(x,2)

 assetsOutliers(x, colMeans(x), cov(x))


 x<- 100/12 * assetsSim(n = 120, dim = 4)

 dim(x)

 head(x,2)


# ---------------------

 x<-1:6

 x

 cumsum(x)