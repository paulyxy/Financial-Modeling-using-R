# c16_p266_3_installRcommand.R

 install.packages('ttrTests')