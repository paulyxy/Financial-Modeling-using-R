# c16_p243_2lines_install_all_fin_packages.R

 install.packages("ctv")

 library(ctv)

 install.views("Finance")


