# c16_p249_package_fOptions.R


 require(fOptions)

 GBSOption(TypeFlag="c",S=60,X=65,Time=1/4,r=0.08,b=0.08,sigma=0.30)


 BSAmericanApproxOption(TypeFlag ="c",S = 42, X = 40,Time = 0.75, r = 0.04, b = 0.04-0.08, sigma = 0.35)


 RollGeskeWhaleyOption(S = 80, X = 82, time1 = 1/4, Time2 = 1/3, r = 0.06, D = 4, sigma = 0.30)



