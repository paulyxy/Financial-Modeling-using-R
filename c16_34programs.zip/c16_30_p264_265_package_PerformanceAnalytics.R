# c16_p264_265_package_PerformanceAnalytics.R


require(PerformanceAnalytics)

stock<- managers[, "HAM2", drop=FALSE]

mkt<- managers[, "SP500 TR",drop=FALSE]

rf<- managers[, "US 3m TR",drop=FALSE]

CAPM.beta(stock,mkt,rf)


# --------------------------------

 CAPM.beta.bull(stock,mkt,rf)

 CAPM.beta.bear(stock,mkt,rf)

require(tseries)

require(quantmod)

require(PerformanceAnalytics)

getSymbols('ibm',src='yahoo')

x<-monthlyReturn(IBM)

SharpeRatio(x, Rf=.035/12, FUN="StdDev")


 TreynorRatio(stock,mkt,rf)


require(tseries)
require(quantmod)
require(PerformanceAnalytics)
getSymbols('ibm',src='yahoo')
x<-dailyReturn(IBM)
 VaR(x,p=0.95,method="gaussian")