# c16_p262_package_ttrTests.R

 library(ttrTests)

 x<-c(1,3,NA,3,5,NA)

 y<-deleteNA(x)



