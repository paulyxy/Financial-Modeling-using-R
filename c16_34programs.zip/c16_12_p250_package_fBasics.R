# c16_p2450_package_fBasics.R



 require(fBasics)

 set.seed(123)

 x<-timeSeries(matrix(rnorm(12)), timeCalendar())

 basicStats(x)


