# c16_p258_codes.R




library(tseries)
n <- 1100
a <- c(0.1, 0.5, 0.2) # ARCH(2) coefficients
set.seed(12345) # fix a seed
e <- rnorm(n) # generate a set of random numbers
x <- double(n) # make sure they are in a correct format
x[1:2] <- rnorm(2, sd = sqrt(a[1]/(1.0-a[2]-a[3])))

for(i in 3:n) { # generate ARCH(2) process
       x[i] <- e[i]*sqrt(a[1]+a[2]*x[i-1]^2+a[3]*x[i-2]^2)
}

x <- ts(x[101:n]) # skip the first 100 numbers

x.arch <- garch(x, order = c(0,2)) # Fit ARCH(2)
