# c16_p251_package_fBonds.R


 library(XML)

 x<-readHTMLTable("http://finance.yahoo.com/bonds")[[2]][,1:2]

 require(fBonds)

 r<-as.numeric(as.matrix(x$Yield))/100

 r


