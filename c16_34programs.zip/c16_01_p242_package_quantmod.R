# c16_p242_package_quantmod.R

 library(quantmod)

 getQuote("ibm",src='yahoo')


 x<-getQuote("ibm",src='yahoo')

 length(x)

 x[2]


