#  c04_p75_grep.R


   x[grep('Total Current',rownames(x)),]


