#  c04_p85_load_is50RData.R

 con<-url("http://canisius.edu/~yany/RData/is50.RData")
 
 load(con)
 
 close(con)

 head(is50)



# note the old code is
# con<-url("http://canisius.edu/~yany/is50.RData")