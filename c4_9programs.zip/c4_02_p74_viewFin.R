#  c04_p73_readHTML_example.R



 library(quantmod)         

 x<-viewFin(getFin("DELL",auto.assign=FALSE),"BS","A") 


