#  c04_p80_AAPL.R


 library(quantmod)

 getFinancials("AAPL")        

 x<-viewFin(AAPL.f,"IS","A") # IS: Income statement, A for Annual

 dim(x)                      








