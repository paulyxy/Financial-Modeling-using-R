#  c04_p73_readHTML_example.R



 library(XML)

 x<-readHTMLTable("http://www.marketwatch.com/investing/stock/IBM/financials")

 x[[1]]  




