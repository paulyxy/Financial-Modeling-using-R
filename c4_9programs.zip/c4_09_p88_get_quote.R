#  c04_p88_get_quote.R


 library(quantmod)

 getQuote("IBM")
