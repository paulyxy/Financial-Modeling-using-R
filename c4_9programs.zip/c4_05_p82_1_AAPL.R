#  c04_p82_AAPL.R

 library(quantmod)

 getFinancials("AAPL")        

 y<-viewFin(AAPL.f,"BS","A")  # BS:Balance Sheet, A=Annual

 dim(y)                       








