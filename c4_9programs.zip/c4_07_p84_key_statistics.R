#  c04_p84_key_statistics.R


 library(XML)

 x<-readHTMLTable("http://finance.yahoo.com/q/ks?s=ibm+Key+Statistics")

 x[[8]]



"
Old codes

 library(XML)

 x<-readHTMLTable("http://finance.yahoo.com/q/ks?s=dell+Key+Statistics")

 x[[10]]




" 









