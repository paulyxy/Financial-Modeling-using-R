#  c04_p82_83_current_ratio_IBM.R


 library(quantmod)

 getFinancials("IBM") 

 x<-viewFin(IBM.f,"BS","A")  #  IS=Income statement,A=Annual

 CA<-x[grep('Total Current Ass',rownames(x)),]

 CL<-x[grep('Total Current Lia',rownames(x)),]

 CA/CL









